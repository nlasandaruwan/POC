package lambda.functionalInterfaces;

public interface Methodreference {

}
