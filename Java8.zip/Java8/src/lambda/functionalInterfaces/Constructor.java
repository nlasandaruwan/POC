package lambda.functionalInterfaces;

@FunctionalInterface
public interface Constructor <T>{

	T get();
	
}
