package lambda.functionalInterfaces;

@FunctionalInterface
public interface Compare <T>{

	public boolean compare(T t1);
}
