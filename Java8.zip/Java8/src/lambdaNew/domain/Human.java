package lambdaNew.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@AllArgsConstructor
@Setter
@Getter

public class Human {
	
	private String name;
    private int age;
    
}
