package lambdaNew.functionalInterfaces;

public interface Sayable {

	void say();  
}
