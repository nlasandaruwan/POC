package lambdaNew.functionalInterfaces;

public interface Compare<T, Y> {

	public boolean compare(T t, Y y);

}
