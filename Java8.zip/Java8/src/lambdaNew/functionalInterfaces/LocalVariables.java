package lambdaNew.functionalInterfaces;

public interface LocalVariables {

	void processLocal();
}
