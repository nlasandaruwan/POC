package coreservlets;

public interface HealthPlanFinder {
  HealthPlan findPlan(String planName);
}
