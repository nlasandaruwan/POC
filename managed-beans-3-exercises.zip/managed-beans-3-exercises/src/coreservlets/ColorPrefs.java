package coreservlets;

import java.io.Serializable;
import javax.faces.bean.*;

@ManagedBean
@SessionScoped
public class ColorPrefs implements Serializable {
  private static final long serialVersionUID = 1L;
  private final String DEFAULT_FOREGROUND = "black";
  private final String DEFAULT_BACKGROUND = "#fdf5e6";
  private String foreground = DEFAULT_FOREGROUND;
  private String background = DEFAULT_BACKGROUND;
  
  public String getForeground() {
    return(foreground);
  }
  
  public void setForeground(String foreground) {
    if (!isMissing(foreground)) {
      this.foreground = foreground;
    }
  }
  
  public String getBackground() {
    return(background);
  }
  
  public void setBackground(String background) {
    if (!isMissing(background)) {
      this.background = background;
    }
  }
  
  public String checkColors() {
    if (foreground.equalsIgnoreCase(background)) {
      foreground = DEFAULT_FOREGROUND;
      background = DEFAULT_BACKGROUND;
    }
    return(null); // Redisplay form
  }
  
  private boolean isMissing(String name) {
    return(name.trim().isEmpty());
  }
}
