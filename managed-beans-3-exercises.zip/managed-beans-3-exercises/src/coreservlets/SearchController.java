package coreservlets;

import java.io.*;

import javax.faces.bean.*;
import javax.faces.context.*;
import javax.servlet.http.*;
import java.net.*;

@ManagedBean
public class SearchController {
  private String searchString="";
  private final static String GOOGLE_URL="https://www.google.com/#q=";
  private final static String BING_URL="http://www.bing.com/search?q=";
  
  public String getSearchString() {
    return(searchString);
  }

  public void setSearchString(String searchString) {
    this.searchString = searchString.trim();
  }

  public String doSearch() throws IOException {
    searchString = URLEncoder.encode(searchString, "utf-8");
    String searchUrl;
    if (Math.random() > 0.5) {
      searchUrl = GOOGLE_URL + searchString;
    } else {
      searchUrl = BING_URL + searchString;
    }
    ExternalContext context =
      FacesContext.getCurrentInstance().getExternalContext();
    HttpServletResponse response =
      (HttpServletResponse)context.getResponse();
    response.sendRedirect(searchUrl);
    return(null);
  }
}
